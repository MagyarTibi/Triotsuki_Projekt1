$('.expandHome').mouseover(function () {
    $('.sub-home').css({
        'display': 'block'
    });
});
$('.subnavbtn').mouseover(function () {
    $('.sub-home').css({
        'display': 'none'
    });
});

$('#trapezoid').mouseleave(function () {
    $('#trapezoid').css({
        'margin-top': '-53px'
    });
    $('.sub-home').css({
        'display': 'none'
    });
}).mouseenter(function () {
    $('#trapezoid').css({
        'margin-top': '-10px'
    });
});


